#pt2
class Employee_Bonus: 
  def __init__(self,salary,rate):
    #to this class 
    self.salary=salary
    self.rate=rate 
    self.bonus= salary * rate
    return Employee_Bonus

  
  #Vid pt
class Employee:
  def __init__(self, first, last, pay):
    self.first=first
    self.last=last
    self.pay=pay
    self.email= first +'.'+ last + '@company.com'
    
 
  #Fullname=METHOD
  #instance (self) automatically passed
  def fullname(self):
    return '{} {}'.format(self.first, self.last)

  def Employee_Bonus(self):
    return salary * rate
    
Emp1= Employee('Michael', 'Smith', '5000')
Emp2= Employee('Asha', 'Samuel', '9000')

print(Emp1.email)
print(Emp2.email)

print(Emp1.fullname())
#print(Employee.fullname(Emp1))

#print(Emp2.fullname())
print(Employee.fullname(Emp2))
# LNS 20 & 23--Alternative:run methods using class name itself without object
#When running class name---manually pass instance as argument


