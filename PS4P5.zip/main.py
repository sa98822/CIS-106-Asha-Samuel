#input
Lname=str(input("Enter lastname:"))
dep= int(input("Enter number of dependents:"))

gross= float(input("Enter gross income:$"))

#process

adj= gross- 1200* dep

if adj> 50000.00:
  taxrate= adj*0.20
else: 
  taxrate= adj* 0.10

incometax=adj* taxrate
if incometax<0:
  incometax=100


#output
print("Last name:",Lname)
print("Gross income:$ ",gross)
print("Dependents:",dep)
print("Adjusted gross income:$ ",adj)
print("Income tax:$ ",taxrate)