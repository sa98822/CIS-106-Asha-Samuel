class Car:
  def __init__(self, make, model, MSRP):
      self.make = make
      self.model = model
      self.MSRP = MSRP

  def discprice(self):
      return 0.9 * self.MSRP

  def optionsprice(self):
      return self.discprice()

#Derived Class
class Sport(Car):
  def __init__(self, make, model, sticker_price, sport_wheels='N', sport_engine='N', sport_interior='N'):
      super().__init__(make, model, sticker_price)
      self.sport_wheels = sport_wheels
      self.sport_engine = sport_engine
      self.sport_interior = sport_interior
# 3 options METHODS
  def SportWheels(self):
      return 1000.00 if self.sport_wheels.upper() == 'Y' else 0.00
 
  def SportEngine(self):
      return 3000.00 if self.sport_engine.upper() == 'Y' else 0.00

  def SportInterior(self):
      return 2000.00 if self.sport_interior.upper() == 'Y' else 0.00

  def optionsprice(self):
      ttlprice = super().optionsprice()
      ttlprice += self.SportWheels()
      ttlprice += self.SportEngine()
      ttlprice += self.SportInterior()
      return ttlprice


# Example and set to Y
car1 = Sport(make='Toyota', model='Camry', sticker_price=25000, sport_wheels='Y', sport_engine='N', sport_interior='Y')
print(f"Make: {car1.make}, Model: {car1.model}")
print(f"Sticker Price: ${car1.MSRP:.2f}")
print(f"Discount Price: ${car1.discprice():.2f}")
print(f"Price with Options: ${car1.optionsprice():.2f}")