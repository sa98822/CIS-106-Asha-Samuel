#input
name= str(input("Enter name of appliance"))
costapp= float(input("Enter cost of the appliance $ "))

#process

if costapp > 1000 :
  warranty = 0.1 * costapp
else: 
  warranty= 0.05 * costapp

total=costapp + warranty

#output

print("Name of appliance:", name)
print("Cost of appliance:$ ",costapp)
print("Cost of warranty",warranty)
print("Total cost:$ ",total)
