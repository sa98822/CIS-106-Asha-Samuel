
#Input student info
first = input("Enter your first name: ")
last = input("Enter your last name: ")
dcode= input("Enter district code: (I/O)")
credits=float(input("Enrolled credit hours="))

# Calculate costpercredits based on the district code provided
costpercredits = 25.0 if dcode == "I" else 55.0

class Student:
  def __init__(self, first, last, dcode,credits):
    self.first=first
    self.last=last
    self.dcode= dcode
    self.credits = credits
    self.tuition= costpercredits * credits

#Creating Instance of Student using info
student= Student(first, last, dcode, credits)

#Student is now an object
print(student.tuition)