n= int(input("Enter # of integer numbers for list:"))
list1=[]
for _i in range(0,n,1):
  #x= int(input("Enter an integer value:"))
  list1.append(int(input("Enter an integer value:")))
print([list1])

#insert 99 at position1
list1.insert(1,99)
print(list1)

for i in range(0,len(list1)):
  if list1[i]==99:
    list1[i]=100
print(list1)

#LIST 2 
list2=[500, 600, 700, 800, 900]
print(list2)
list1.extend(list2)

list1.remove(800)
print(list1)

list1.pop(2)

#LIST OF GRADES
grades = ["A", "B", "C", "A", "A", "C"]

B= grades.index("B")
print(B)    #print index of B

F_grade= grades.index('F')
if F_grade in grades:
  print([F_grade])
else:
  print(F_grade, "is not in the list.")

list2.clear()
print(list2)

del list2
print(list2)

#LIST OF PLAYERS
players=["Rizzo", "Davis", "Baez", "Happ", "Bryan"]
players.sort()
print(players)

print(players.reverse())
