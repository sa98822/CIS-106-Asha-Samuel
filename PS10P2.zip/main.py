def ComputePoints(exam1,exam2,exam3):
  ttlpts= exam1 +exam2+exam3
  avgscore=ttlpts/3
  return ttlpts, avgscore

#main
Lname=input("Last name:")
exam1=float(input("exam1 score:"))
exam2=float(input("exam2 score:"))
exam3=float(input("exam3 score:"))

ttlpts, avgscore= ComputePoints(exam1,exam2,exam3)

print("Last name:",Lname)
print("Total points:",ttlpts)
print("Average exam score: ", avgscore)