def Computedisc(qty,price,discrate):
  discamt=qty*price*discrate
  discprice= qty*price-discamt
  return discamt, discprice
  
#Main
qty=int(input("Enter quantity:"))
price=float(input("Enter price:$ "))
discrate=float(input("Enter discount rate-"))

discamt, discprice=Computedisc(qty,price,discrate)

print("Qauntity of items=",qty)
print("Item price=",price)
print("Enter amount of discount",discamt)
print("Enter discounted price",discprice)