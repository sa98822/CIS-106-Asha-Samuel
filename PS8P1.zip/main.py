#Calculate extp Function
def CompExtPrice(qty,price):
  extprice=qty*price
  if extprice>1000:
    discamt= extprice* 0.10
  else:
    discamt=0

  newextprice=extprice-discamt
  return newextprice

#Main Function
totalextprice=0

response=input("Do you want to do this program? (Yes or No)")

while response=="yes":
  qty=float(input("Enter quantity of items:"))
  price=float(input("Enter price:"))
  Extprice = CompExtPrice(qty,price)

  #sum and display
  totalextprice=totalextprice + Extprice
  print("Extended price:$", Extprice)

  response=input("Do you want to do this program? (Yes or No)")

print("Total Extended Price:$ ", totalextprice)




