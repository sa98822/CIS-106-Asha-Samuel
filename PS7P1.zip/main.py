#input

response= str(input("Would you like to see your costs? yes or no? "))
if response== "yes":
  print("Continue program")

  ttlint=0
  p= float(input("Enter principle amount:$ "))
  rate= float(input("Enter interest rate:$ "))

  #year= count variable
  for count in range (1,6,1):
    interest= p * rate
    endbalance= p + interest
    print(count,"  ", p,"  ", endbalance)
    p=endbalance
    ttlint=ttlint+ interest

  print("Accumulated interest:$ ",ttlint)

else:
  print("End program")