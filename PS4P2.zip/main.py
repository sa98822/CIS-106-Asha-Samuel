#input
item= (input("Enter item (A or B)"))
qty= int(input("Enter quantity"))

#process

if item== "A":
  uprice=10.00
else: 
  uprice=20.00

extprice= qty * uprice

#output

print("Item entered-",item)
print("Unit price",uprice)
print("Extended price",extprice)
