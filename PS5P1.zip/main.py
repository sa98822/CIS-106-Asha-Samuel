#input
qty= int(input("Enter quantity"))
price = 0
#process phase
if qty>10000:
  price=10
else:
  if (qty>=5000) and (qty<=10000):
    price=20
  else:
    qty=300

extprice= qty * price 
tax= 0.07* price 
total= extprice + tax


#output
print("Quantity:", qty)
print("Extended price: $",extprice)
print("Total: $",total)