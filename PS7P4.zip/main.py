# connect to the file
f = open("p4.py", "r")
count=0
ttlep=0

item= f.readline()

#loop as long as the last readline is not null
while item != "":
  qty=int(f.readline())
  price= float(f.readline())
  ep= qty * price
  count=count+1
  ttlep= ttlep + ep
  print("Item:",item)
  print("Quantity",qty)
  print("Price:$",price)
  print("Extended price:$",ep)
 
  item= f.readline()

  #After Loop
f.close()
print("Sum of Extended Prices=", ttlep )
print ("Total Orders: ",count)
avg= ttlep/count
print("Average order:",avg)