#input

qty= float(input("Enter quantity of item:" ))

#process
 
if qty >= 1000: 
  up= 3.0
else:
  up= 5.0

extprice= qty * up
tax= 0.07 * extprice
total= extprice +tax

#output
print("Enter quantity:",qty)
print("Unit price:$ ",up)
print("Extended price:$ ",extprice)
print("Tax:$ ",tax )
print("Total:$ ", total)