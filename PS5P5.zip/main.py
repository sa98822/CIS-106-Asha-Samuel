#input

Lname= input("Enter Last name-")
salary=float(input("Enter salary:$ "))
level= int(input("Enter real job level"))

#process
if level>=10:
  rate=0.25
elif level>=5 and level<=9:
  rate=0.20
else:
  level=0.10

bonus=salary*rate

#output

print("Last name:",Lname)
print("Bonus:$ ",bonus)