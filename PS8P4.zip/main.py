def calcPayrate(code):
  payrate = 0
  if code=="L":
    payrate=25.00
  elif code=="A":
    payrate=30.00
  elif code=="J":
    payrate=50.00
  return payrate
  
#Main function
response= input("Do you want to calculate your gross pay?")
while response== "yes":
  c=0
  Lname=input("Enter Last name")
  code= str(input("Enter job code here"))
  hrs=float(input("Hours worked"))
  payrate= calcPayrate(code)
  gross = hrs * payrate
  
  c=c+1
  print("Employee last name:",Lname)
  print("Gross pay: ",gross)
  response= input("Do you want to continue?")

print("Sum of all gross pays:",gross)
  