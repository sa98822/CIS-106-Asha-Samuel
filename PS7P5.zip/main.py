f= open("file5.py", "r")

c=0
ttltuition=0

# getting first part of data

Lname= f.readline().rstrip('\n')

while Lname!="":
  districtcode=str(f.readline())
  credits=int(f.readline())

  if "I" in districtcode:
    credcost=250.0
  elif "O" in districtcode:
    credcost=500.0

  tuition=credits*float(credcost)
  c=c+1
  ttltuition=ttltuition+tuition

  print("Last name:",Lname)
  print("Credits taken:", credits)
  print(f"tuition:${tuition:.2f} \n")
  Lname=f.readline()
#END OF LOOP

f.close()
print("Total tuition:$", ttltuition)
print("Student count:",c)
  







  


  