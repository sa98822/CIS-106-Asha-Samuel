#input phase
start=int(input("Enter start value: "))
stop=int(input("Enter stop value: "))
incr= int(input("Enter increment value: "))

num=start             #initialize flag
#while loop
while num<= stop:    #condition
  print(num)
  num= num + incr     #update flag for repetition till stop
  
  
