#input

start=1
stop=25
incrvalue=2
count=0
while start<=stop:
  print(start)
  start=start+incrvalue

#output
print("Odd numbers between 1-25")