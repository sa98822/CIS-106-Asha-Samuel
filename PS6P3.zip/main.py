#input

entry=input("Would you like you continue?")

#count declared for line 28
count = 0

if  entry=="yes":			
  print("continue")
else:
  print("End of program")

# WHILE LOOP 
#While flag:
#test expression=   While flag:
#commands/actions
#update flag        increment

while entry== "yes":
  Lname= str(input("Please enter Last Name- "))
   
  #process phase
  score1= float(input("Enter your 1st exam score: "))
  score2= float(input("Enter your 2nd exam score: "))
  
  avgscore= (score1+ score2)/2

  count=count+1   #increment
  print("Last name: ",Lname)
  print("Average exam score: ",avgscore)

  #repromt user
  entry=input("Would you like you continue?")
#End of While Loop
  
print(count)
  
 
  
  
  