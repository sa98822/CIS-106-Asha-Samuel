#input

partnum= int(input("Enter part number "))
qty= int(input("Enter qauntity "))

#process
if partnum==10 or partnum==55: 
  unitcost=1.00
else:
  if partnum==99:
    unitcost=2.00
  else:
    if partnum==80 or partnum==70:
      unitcost=3.00
    else:
      unitcost=5.00


total= qty* unitcost

#output 
print("Parnumber:# ",partnum)
print("unitcost=$ ",unitcost)
print("Total cost: $",total)

#end

#next time use elif____ :
#if parnum==10 or partnum==55:
  #unitprice=1.00
#elif parnum==99:
  #unitprice=2.00
 