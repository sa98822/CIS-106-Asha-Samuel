#input

qty= int(input("Enter amount of tickets"))


#process

if qty>=25:
  tprice=50
elif qty>=10 and qty<=24:
  tprice=60
elif qty>=5 and qty<=9:
  tprice= 70
elif qty<5:
  tprice=75

total=qty *tprice


#output

print("Tickets purchased:",qty)
print("Price per ticket:$ " ,tprice)
print("Total cost:$ ",total)