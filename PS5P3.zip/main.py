#input
princ= float(input("Enter principle amount $"))
maturity= float(input("What is the year to maturity? "))

#process

if princ>100000 and maturity==5:
  rate=0.06
elif princ>=50000 and princ<=100000 and maturity==10: 
  rate=0.05
elif princ>=50000 and princ<=100000 and maturity==5:
  rate=0.04
else: 
  rate=0.02

intamt= princ*rate


#output

print("Principle amount:$ ",princ)
print("Interest rate:$ ",rate)
print("Interest amount:$ ",intamt)