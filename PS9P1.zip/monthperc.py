Month			Forecast Percent
Jan, Feb, Mar			0.10
Apr, May, Jun			0.15
Jul, Aug, Sep			0.20
Oct, Nov, Dec			0.25
