#compnextforecast
#1. determine next forecast percent     
def compnextforecast(month,sales):

  if month in ("Jan", "Feb", "Mar"):
      forecastperc = 0.10	
  elif month in ("Apr", "May", "Jun"):
      forecastperc = 0.15
  elif month in ("Jul", "Aug", "Sep"):
      forecastperc = 0.20
  elif month in ("Oct", "Nov", "Dec"):
      forecastperc = 0.25
  else:
    forecastperc=0.0
  
  nextsales = sales * (1 + forecastperc)
  return nextsales

#Main

response= input("Would you like to do the program? (Yes or No) ")
while response=="Yes":
  Lname=input("Enter last name:")
  month=str(input("Enter month:"))
  sales=float(input("Enter sales:"))
  
  nextsales=compnextforecast(month,sales)  

  print("Value of next month's sales:", nextsales)
  response= input("Would you like to do the program? (Yes or No) ")

  
