def DisplayArr(Lname, batavg):
  for i in range(len(Lname)):
    print(f"{Lname[i]}: {batavg[i]}")

def SearchLname(Sname, Lname, batavg):
  #  create & use index keeping track of position in array
  position = -1
  #if loop used to Display w/ Sindex as loop ctrl var
  for i in range(len(Lname)):
    if Lname[i] == Sname :
      position = i 
  return position


#MAIN
#open/connect data file
f = open("empl.py", "r")
#prime read
Lname = []
batavg = []
name = f.readline().strip()
while name != "":
  # Store in lists
  Lname.append(name)
  bat = f.readline().strip()
  batavg.append(int(bat))
  name = f.readline().strip()
f.close()

DisplayArr(Lname, batavg)

response= input("Do you want to do this program: Y or N?")
#repeatedly ask user for lname
while response== "Y":
  Sname= input("Enter a Last name you would like to search:")
  Sindex = SearchLname(Sname,Lname,batavg)
  # Sname= input("Enter a Last name you would like to search:")

  if Sindex ==-1:
    print("Name not found")
  else: 
    print(Lname[Sindex],"has a batting average of ",batavg[Sindex] )
    # print(batavg[Sindex])

print("End of program")
  