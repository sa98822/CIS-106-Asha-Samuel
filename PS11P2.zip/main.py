# parallel array-- add array w/ score  (Lname +Score )
def DisplayArrayLname(Lname):
  for i in range(0,10):
    print(Lname[i])
  # OR for i in Lname:
      # print(i)

def DisplayReverse(Lname):
  for i in range (9,-1,-1):
    print(Lname[i])

def LnameScore(Lname,score):
    for i in range(0,10):
      print(Lname[i],score[i])

#MAIN
Lname= ["Smith","Jones","Williams","Brown", "Taylor", "Evans", "Thomas", "Samuel", "Joseph", "Scott"]

score=[10,20,30,40,50,60,70,80,90,100]

DisplayArrayLname(Lname)
print('Reverse  Lastname Order')
DisplayReverse(Lname)
LnameScore(Lname,score)


# initialize/declare arrays in Main
#for index in arr=(  ):  AKA for i in range():
### RANGE (start,stop, incr.value)
 # print(arr[index])