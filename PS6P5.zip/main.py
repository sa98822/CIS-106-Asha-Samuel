#input prompt user for response
count=0
sumdiscamt=0
extprice=0
disc=0
response= str(input("Would you like to start? yes or no? "))
if response== "yes":
  print("Continue")
else:
  print("exit program")

#While Loop
while response== "yes":
  count=count +1
  qty=int(input("Enter quantity: "))
  price=float(input("Enter price: "))
  extprice= qty* price
  if extprice>10000.00:
    disc=0.25
  else: 
    disc= 0.10
  response= str(input("Would you like to start? yes or no? "))

  #End of Loop
discamt= extprice * disc
sumdiscamt=sumdiscamt +discamt
total=extprice - discamt
print("Extended price: ", extprice)
print("Discount amount: ", discamt)
print("Total:", total)

response= str(input("Would you like to start? yes or no? "))
  
  

