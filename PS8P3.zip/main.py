def Compmpg(mi,gal):
  mpg=mi/gal
  return mpg

#Main
count=0

response= input("Would you like to start?")
while response=="yes":

  city=input("Enter city- ")
  mi=float(input("Miles travelled"))
  gal= float(input("Gallons "))
  
  mpg= Compmpg(mi, gal)
  
  
  print("Destination city:", city)
  print("Miles traveled: ", mi)
  print("Gallons used: ", gal)
  print("Miles per gallon:",mpg)
  
  response= input("Would you like to continue?")
  count=count+1
print("Entries made:", count)