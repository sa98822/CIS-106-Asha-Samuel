ttl=0
tax=0

def CalcTotal(qty, uprice):
  global ttl
  global tax
  ttl=qty *uprice
  tax= 0.07* ttl
  return ttl, tax

qty=int(input("Enter quantity:"))
uprice= float(input("Enter unit price:"))

ttl,tax =CalcTotal(qty, uprice)
print("Total:$",ttl)
print("Tax:$","{:.2f}".format(tax))

