#input- prompt user input
response=input("Do you want to continue? yes or no?")

if response== "yes":
  print("continue")
else:
  (print("Stop program"))

#initialize to 0
sumgross=0
count=0      #ttl employees

#while loop
while response== "yes":
  Lname= input("Enter employee last name: ")
  hrs= float(input("Enter hours worked: "))
  rate= float(input("Enter pay rate: "))
 
  
  if hrs > 40:     #relational condition
    overhours=hrs-40
    gross= (hrs * rate) +(1.5 * overhours * rate)
  else:
     gross = hrs * rate 

  print("Last name: ",Lname)
  print("Gross pay= ",gross)

  sumgross=sumgross+ gross
  count=count+1        #ttl employees

  #prompt response
  response= input("Do you want to continue? yes or no?")
  
print("Total gross pay: ",sumgross)
print("Number of Employees: ", count)

if count>0:     #cannot divide by 0
  avg= (sumgross/count)
  print("Average gross pay: ",avg)







