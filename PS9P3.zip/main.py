#Function calctotal 
#1 Determine the % off MSRP
##2 compute the new MSRP
##3 add 7% tax to total
def calcsaleprice(make,model,MSRP):
  if make=="Honda" and model=="Accord":
    percoff=0.10
  elif make== "Toyota" and model== "RAV4": 
    percoff=0.15
  elif code== "y":
    percoff=0.30
  else: 
    percoff=0.05

  discount= MSRP *percoff
  tax= MSRP* 0.07
  saleprice= MSRP - discount + tax
  return saleprice
    
  
#Main
ttlMSRP=0
ttlsaleprice=0
response= input("Would you like to do the program? (Yes or No) ")
while response=="Yes":
  make= (input("Enter Make:"))
  model= (input("Enter model:"))
  code=input("Is car electric?" )
  MSRP= float(input("Enter MSRP:"))

  ttlMSRP= ttlMSRP +MSRP
  saleprice=calcsaleprice(make,model,MSRP)
  
  ttlsaleprice= ttlsaleprice + saleprice
  print("Sum of saleprices/totals",saleprice)
  print("Sum of MSRP values: $",ttlMSRP)
  response= input("Would you like to do the program? (Yes or No) ")


