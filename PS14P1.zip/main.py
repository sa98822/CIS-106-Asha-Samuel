#pt2  #Define Employee_Bonus Class
class Employee_Bonus: 
  def __init__(self,salary,rate):
    #to this class 
    self.salary=salary
    self.rate=rate 
    self.bonus= self.salary * self.rate
    return Employee_Bonus

  def Employee_Bonus(self):
    return self.salary * self.rate

  #Define Employee Class
class Employee:
  def __init__(self, first, last, pay):
    self.first=first
    self.last=last
    self.pay=pay
    self.email= first +'.'+ last + '@company.com'
 #Fullname=METHOD
  def fullname(self):
    return '{} {}'.format(self.first, self.last)
  
############
class Manager(Employee):
  def __init__(self, first, last, salary):
      super().__init__(first, last, salary)

  def long_term_bonus(self):
      return self.pay * 0.4
 
# Create manager object
manager = Manager("First", "Last", 100000)

print("Manager Name:", manager.last)
print("Manager salary: $", manager.pay)
print("Manager's Long-Term Bonus: $", manager.long_term_bonus())
  
#Creat Employees
Emp1= Employee('Michael', 'Smith', '5000')
Emp2= Employee('Asha', 'Samuel', '9000')

print(Emp1.email)
print(Emp2.email)
print(Emp1.fullname())
#print(Employee.fullname(Emp1))

print(Employee.fullname(Emp2))
# LNS 20 & 23--Alt.:run methods using class name itself without object

