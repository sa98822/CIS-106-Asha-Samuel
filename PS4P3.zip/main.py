
qty= int(input("Enter number of books"))
costperbook= float(input("Enter cost per book"))

#process

orderttl= qty* costperbook


if orderttl >50:
  ship=0
else: 
  ship=25.00

#output
print("order total:$",orderttl)
print("shipping charge:$",ship)