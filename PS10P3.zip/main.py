def Computesales(sales,percentsales):
  comm= sales* percentsales
  nexttarget=sales * 0.05
  return comm, nexttarget

Lname=input("Enter salesperson last name:")
sales=float(input("Enter sales"))

if sales>=100000:
  percentsales=0.10
else :
  percentsales=0.05
comm, nexttarget=Computesales(sales, percentsales)

print("Salesperson last name is",Lname)
print("Commission:",comm)
print("Next year's target price is ",nexttarget)