#(start, stop,)

#x+y=z
x=1
y=1
print(x)
print(y)

for count in range (1,19,1):
  z=x+y
  print(z)
  x=y
  y=z
  

