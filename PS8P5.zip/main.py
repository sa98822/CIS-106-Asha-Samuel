#external function should receive hrs & code
#return tuition owed

def CompTuitionOwed(hrs,code):
  tuition=0
  if code== 'I':
    tuition=250 * hrs
  elif code== 'O':
    tuition=550 *hrs
  else:
    print("Code doesn't exist!!")
  return tuition

#Main 
totaltuition=0
response= input("Would you like to calculate tuition?")

while response=='y':
#input Lname, hrs, code
  Lname=input("Last name:")
  hrs= int(input("Credit hours:"))
  code=input( "District Code-- (I/O)")
  
  tuition= CompTuitionOwed(hrs,code)
  
  print("Last name:",Lname)
  print("Tuition owed:",tuition)
  totaltuition=totaltuition+tuition

  response= input("Would you like to calculate tuition?")
#display Lname, tuition, ttltuition
print("Total tuition owed:", totaltuition)
