def CompBattingAvg(hits,bats):
  BattingAvg= hits/bats
  return BattingAvg

#Main
count=0
response= input("Do you want to find batting average?")
if response=="yes":

  Lname= str(input("Last name- "))
  hits= float(input("Number of hits:"))
  bats= float(input("Number of bats"))
  
  BattingAvg=CompBattingAvg(hits,bats)
  
  print("Last name is ",Lname)
  print("Batting Average= ",BattingAvg)
  count=count+1
  response=input("Do you want to continue?")
  
print("Total players:", count)