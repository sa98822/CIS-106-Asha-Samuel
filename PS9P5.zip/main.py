def Assessedvalue(county, mvalue):
  if county== 'Cook' :
    avalueperc=0.9
  elif county== 'DuPage':
    avalueperc= 0.8
  elif county== 'McHenry':
    avalueperc= 0.75
  elif county== 'Kane':
    avalueperc= 0.60
  else:
    avalueperc= 0.70
  
  avalue= mvalue*avalueperc
  return avalue

#Main
ttlmvalue=0
ttlavalue=0
r=input("Would you like to do the program?'[yes'or'no']") 
while r=='yes':
  county=(input("Enter county:"))
  mvalue= float(input("Market value: $"))
  avalue= Assessedvalue(county, mvalue)
  ttlmvalue=ttlmvalue+ mvalue
  ttlavalue=ttlavalue+ avalue

  print("Total market value: $", ttlmvalue)
  print("Total assesed value: $",ttlavalue)
  r=input("Would you like to do the program?'[yes'or'no']") 
