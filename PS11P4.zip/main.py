# parallel array-- add array w/ score  (Lname +Score )
# MAX & MIN

def DisplayArrays(Lname, score):
  for i in range(0, 10):
    print(Lname[i], score[i])

def Max(score):
  high_index = 0
  high_var = int(score[0])
  for i in range(len(score)):
    if score[i] > high_var:
      high_var = score[i]
      high_index = i
  return high_index

def Min(score):
  low_index=0
  low_var = 999
  for i in score:
    if score[i] < low_var:
      low_var = score[i]
      low_index=i
  return low_index


def DisplayMax(Lname, score):
  high_index=Max(score)
  print(" ", Lname[high_index], "has the highest score of",
        score[high_index])

  def DisplayMin(Lname, score):
    low_index = Min(score)
    print(" ", Lname[low_index], "has the lowest score of",
          score[low_index])

#MAIN

# initialize/declare arrays in Main
#for index in arr=(  ):  AKA for i in range():
### RANGE (start,stop, incr.value)
# print(arr[index])
Lname = []
score = []
f = open("namescore.txt", "r")
for _i in range(0, 10):
  Lname.append(f.readline().strip())
  score.append(int(f.readline().strip()))
f.close()

DisplayArrays(Lname, score)
DisplayMax(Lname, score)  # This will show the name with the highest score
