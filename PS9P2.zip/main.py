#compsquarefootage
def computesquarefootage(length,w,h):
  sqft=2 * length * w + 2 * length * h  + 2 * w * h 
  return sqft



#Main

response= input("Would you like to do the program? (Yes or No) ")
while response=="Yes":
  length=float(input("Enter length:"))
  w=float(input("Width of room:"))
  h=float(input("Height of room"))
  
  #Calling Statingment
  sqft=computesquarefootage(length,w,h)
  gal=sqft/50

  print("Gallons needed:",gal)

  response= input("Would you like to do the program? (Yes or No) ")

