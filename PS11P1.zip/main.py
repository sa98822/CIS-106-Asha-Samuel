#1 2 FUNCTIONS= DisplayArray(Lname) + Reverse array
#2 parallel array-- add array w/ score  (Lname +Score )
### RANGE (start,stop, incr.value)
def DisplayArrayLname(Lname):
  for i in range(0,10):
    print(Lname[i])
  # OR for i in Lname:
        #print(i)

def DisplayReverse(Lname):
  for i in range (9,-1,-1):
    print(Lname[i])

Lname= ["Smith","Jones","Williams","Brown", "Taylor", "Evans", "Thomas", "Samuel", "Joseph", "Scott"]

DisplayArrayLname(Lname)
print('Reverse  Lastname Order')
DisplayReverse(Lname)


# initialize/declare array in Main
#for index in arr=(  ):  AKA for i in range():
 # print(arr[index])