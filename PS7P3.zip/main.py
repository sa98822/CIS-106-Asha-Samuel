#connect to data file
f=open("f.py", "r")

count=0
ttlbonus=0
Lname= f.readline().rstrip('\n')

while Lname != "":
  salary= float(f.readline())
  print()
  print("Last name: ",Lname)
  print("Salary:$ ",salary)
  
#WORK ON THIS 
  
  if float(salary) >= 100000.00:
    brate=0.2
  elif float(salary) >=50000.00 and float(salary)<100000.00:
    brate=0.15
  else: 
    brate=0.1
    
  bonus= brate* float(salary)
  print("Bonus: ", bonus)
  ttlbonus=ttlbonus+bonus
  count=count+1
  Lname= f.readline()
  
#End of Loop
f.close()
avg=ttlbonus/count
print("Average Bonus:$",avg)
