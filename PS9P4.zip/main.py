
def Ticketprice(mi):
  if mi>=30:
    tprice=12
  elif 20>=mi>=29:
    tprice=10
  elif 10>=mi>=19:
    tprice=8
  else:
    tprice=5

  
  return tprice

#Main
response= input("Would you like to do the program? (Yes or No) ")
while response=="Yes":
  mi=0
  sumtprice=0
  Lname=input("Enter last name:")
  mi=float(input("How many miles away from Chicago?"))
  tprice= Ticketprice(mi)
  sumtprice=sumtprice+ tprice
  
  print("Ticket price= $",tprice)
  print("Total Ticket price= $", sumtprice)

  response= input("Would you like to do the program? (Yes or No) ")

