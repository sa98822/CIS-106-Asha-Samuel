def CompAvgscore(Lname,gs1,gs2,gs3,handicap):
  ttl= gs1+gs2+gs3
  avgscore=ttl/3
  avghandicap=avgscore + handicap
  return avgscore, avghandicap

Lname= input("Enter bowler last name:")
gs1= float(input("Game score 1:"))
gs2= float(input("Game score 2:"))
gs3= float(input("Game score 3:"))
handicap=float(input("Enter handicap:"))

avgscore,avghandicap=CompAvgscore(Lname,gs1,gs2,gs3,handicap)

print("Bowler last name",Lname)
print("Average score: ", avgscore)
print("Average handicap:", avghandicap)