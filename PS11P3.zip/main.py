# parallel array-- (Lname +Score )
# MAX & MIN

#for index in arr=(  ):  AKA for i in range():
  #range= (start,stop, incr.value)
# print(arr[index])

def DisplayArrays(Lname,score):
  l=len(Lname)
  for i in range(0,l,1):
    print(Lname[i],score[i])

def DisplayMaxMin(Lname,score):
  high_var=0
  low_var=999
  high_index=low_index=0
 
  for i in range(len(Lname)):
    if float(score[i])>float(high_var):
      high_index=i
      high_var=float(score[i])

    if float(score[i])<float(low_var):
      low_index=i
      low_var=float(score[i])

  print("",Lname[low_index], "had the highest score being:",score[high_index])
  print("", Lname[low_index], "had the lowest score being:", score[low_index])


# MAIN
f = open("namescore", "r")
# Initialize/declare arrays
Lname = []
score = []
# Prime read
lastname = f.readline()

while lastname != "":
  Lname.append(lastname.rstrip("\n"))
  scoreline = f.readline().rstrip('\n')  # Ensure this line is getting the scores
  try:
    scr = float(scoreline)
  except ValueError:
    print(f"Couldn't convert '{scoreline}' to float. Check if the namescore file is correctly formatted with scores following names.")
    break
  score.append(scr)
  lastname = f.readline()  # Read the next last name
#scr = float(f.readline().rstrip('\n'))
#score.append(scr)
f.close()

# Call functions
DisplayArrays(Lname, score)
DisplayMaxMin(Lname, score)
